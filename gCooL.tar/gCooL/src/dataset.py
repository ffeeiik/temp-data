import os.path as osp
from torch_geometric.datasets import WikiCS, Coauthor, Amazon
import torch_geometric.transforms as T
from torch_geometric.data import Data
import numpy as np
import torch
# load dataset
def get_dataset(path:str,name:str):
    root_path = osp.expanduser('~/datasets')

    if name=='Coauthor-CS':
        return Coauthor(root=path,name='cs',transform=T.NormalizeFeatures())

    if name=='WikiCS':
        return WikiCS(root=path,transform=T.NormalizeFeatures())

    if name=='Amazon-Computers':
        return Amazon(root=path,name='computers',transform=T.NormalizeFeatures())

    if name=='Amazon-Photo':
        return Amazon(root=path,name='photo',transform=T.NormalizeFeatures())
    
    if name == 'ICDM2023':
        edge_path = osp.join('/home/yuhanli/wangpeisong/gCooL/datasets', 'icdm2023_session1_test_edge.txt')
        feature_path = osp.join('/home/yuhanli/wangpeisong/gCooL/datasets', 'icdm2023_session1_test_node_feat.txt')
        return load_my_dataset(edge_path, feature_path)


    assert False, 'Unknown dataset!'

def load_my_dataset(edge_path, feature_path):
    # 读取边列表和节点特征
    edges = np.loadtxt(edge_path, delimiter=',').astype(int)
    features = np.loadtxt(feature_path, delimiter=',').astype(float)

    # 创建 edge_index
    edge_index = torch.tensor(edges, dtype=torch.long).t().contiguous()

    # 创建节点特征矩阵
    x = torch.tensor(features, dtype=torch.float)

    # 创建 Data 对象
    data = Data(x=x, edge_index=edge_index)
    print(data)
    return data